import os, re, hmac, hashlib, secrets, sqlite3, smtplib
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo
import httpx
from dotenv import load_dotenv

from fastapi import FastAPI, HTTPException, Request, Response, Depends
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, EmailStr, field_validator

BASE = Path(__file__).resolve().parent
load_dotenv(BASE.parent / ".env")
DB_PATH = os.getenv("DATABASE_PATH", "football_live.db")
SESSION_COOKIE = "fl_session"
SESSION_DAYS = 14
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "false").lower() == "true"
ADMIN_BOOTSTRAP_KEY = os.getenv("ADMIN_BOOTSTRAP_KEY", "")
APP_ENV = os.getenv("APP_ENV", "development").lower()
EMAIL_DEV_MODE = os.getenv("EMAIL_DEV_MODE", "false").lower() == "true"
FOOTBALL_API_KEY = os.getenv("FOOTBALL_API_KEY", "").strip()
FOOTBALL_API_BASE = "https://v3.football.api-sports.io"
FOOTBALL_TIMEZONE = os.getenv("FOOTBALL_TIMEZONE", "UTC")
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
SECRET = os.getenv("FL_SESSION_SECRET", "")
if len(SECRET) < 32:
    # Suitable for local demo only; configure FL_SESSION_SECRET before deployment.
    SECRET = "LOCAL-ONLY-" + secrets.token_urlsafe(48)

app = FastAPI(title="FOOTBALL LIVE API", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            display_name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            avatar_url TEXT NOT NULL DEFAULT '',
            favorite_teams TEXT NOT NULL DEFAULT '',
            role TEXT NOT NULL DEFAULT 'user',
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL
        )""")
        # Safe schema upgrades for databases created by earlier versions.
        cols = {r[1] for r in c.execute("PRAGMA table_info(users)").fetchall()}
        if "role" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'")
        if "status" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'active'")
        if "email_verified" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 1")
        if "phone" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN phone TEXT")
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_phone ON users(phone) WHERE phone IS NOT NULL")
        c.execute("""CREATE TABLE IF NOT EXISTS auth_tokens(
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            purpose TEXT NOT NULL CHECK(purpose IN ('verify_email','reset_password')),
            expires_at TEXT NOT NULL,
            used_at TEXT,
            created_at TEXT NOT NULL
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_auth_tokens_user_purpose ON auth_tokens(user_id,purpose)")
        c.execute("""CREATE TABLE IF NOT EXISTS reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reporter_id INTEGER NOT NULL REFERENCES users(id),
            target_user_id INTEGER NOT NULL REFERENCES users(id),
            reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'open',
            created_at TEXT NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS sessions(
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at TEXT NOT NULL
        )""")
init_db()

def hash_password(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=64)
    return salt.hex() + ":" + digest.hex()

def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, digest_hex = stored.split(":", 1)
        candidate = hash_password(password, bytes.fromhex(salt_hex)).split(":", 1)[1]
        return hmac.compare_digest(candidate, digest_hex)
    except Exception:
        return False

def token_digest(token: str) -> str:
    return hashlib.sha256((SECRET + token).encode()).hexdigest()

def public_user(row):
    return {
        "id": row["id"],
        "phone": row["phone"] if "phone" in row.keys() else None,
        "display_name": row["display_name"],
        "avatar_url": row["avatar_url"],
        "favorite_teams": [x for x in row["favorite_teams"].split("|") if x],
        "created_at": row["created_at"],
        "role": row["role"] if "role" in row.keys() else "user",
        "status": row["status"] if "status" in row.keys() else "active",
        "email_verified": bool(row["email_verified"]) if "email_verified" in row.keys() else True,
    }

class Signup(BaseModel):
    phone: str = Field(min_length=7, max_length=20)
    display_name: str = Field(min_length=2, max_length=40)
    password: str = Field(min_length=10, max_length=128)

    @field_validator("phone")
    @classmethod
    def valid_phone(cls, value):
        value = re.sub(r"[\s()\-]", "", value.strip())
        value = value.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
        if not re.fullmatch(r"\+?[1-9]\d{6,14}", value):
            raise ValueError("شماره موبایل معتبر وارد کنید؛ همراه با کد کشور یا بدون آن.")
        return value

    @field_validator("display_name")
    @classmethod
    def clean_name(cls, value):
        value = value.strip()
        if not value: raise ValueError("نام نمایشی الزامی است.")
        return value

class Login(BaseModel):
    phone: str
    password: str

    @field_validator("phone")
    @classmethod
    def normalize_phone(cls, value):
        value = re.sub(r"[\s()\-]", "", value.strip())
        value = value.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
        if not re.fullmatch(r"\+?[1-9]\d{6,14}", value): raise ValueError("شماره موبایل معتبر نیست.")
        return value

class ProfileUpdate(BaseModel):
    display_name: str = Field(min_length=2, max_length=40)
    avatar_url: str = Field(default="", max_length=500)
    favorite_teams: list[str] = Field(default_factory=list, max_length=20)

    @field_validator("avatar_url")
    @classmethod
    def safe_avatar(cls, value):
        value = value.strip()
        if value and not (value.startswith("https://") or value.startswith("http://")):
            raise ValueError("نشانی تصویر باید با http:// یا https:// شروع شود.")
        return value

def issue_auth_token(user_id: int, purpose: str, hours: int = 24) -> str:
    raw = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    with db() as c:
        c.execute("UPDATE auth_tokens SET used_at=? WHERE user_id=? AND purpose=? AND used_at IS NULL",
                  (now.isoformat(), user_id, purpose))
        c.execute("INSERT INTO auth_tokens(token_hash,user_id,purpose,expires_at,created_at) VALUES(?,?,?,?,?)",
                  (hashlib.sha256(raw.encode()).hexdigest(), user_id, purpose,
                   (now + timedelta(hours=hours)).isoformat(), now.isoformat()))
    return raw

def send_auth_email(email: str, purpose: str, token: str) -> bool:
    if APP_ENV != "production" and EMAIL_DEV_MODE:
        return False
    host = os.getenv("SMTP_HOST", "")
    if not host:
        if APP_ENV == "production":
            raise HTTPException(503, "ارسال ایمیل در حال حاضر پیکربندی نشده است.")
        return False
    if purpose == "verify_email":
        subject = "تأیید ایمیل FOOTBALL LIVE"
        url = f"{PUBLIC_BASE_URL}/verify-email?token={token}"
        body = f"برای تأیید ایمیل خود در FOOTBALL LIVE، این پیوند را باز کنید:\n{url}\nاین پیوند ۲۴ ساعت اعتبار دارد. اگر شما درخواست نداده‌اید، این پیام را نادیده بگیرید."
    else:
        subject = "بازیابی رمز عبور FOOTBALL LIVE"
        url = f"{PUBLIC_BASE_URL}/reset-password?token={token}"
        body = f"برای تعیین رمز عبور جدید در FOOTBALL LIVE، این پیوند را باز کنید:\n{url}\nاین پیوند ۱ ساعت اعتبار دارد. اگر شما درخواست نداده‌اید، این پیام را نادیده بگیرید."
    msg = EmailMessage(); msg["Subject"] = subject
    msg["From"] = os.getenv("SMTP_FROM", os.getenv("SMTP_USER", "noreply@football-live.local"))
    msg["To"] = email; msg.set_content(body)
    port = int(os.getenv("SMTP_PORT", "587"))
    with smtplib.SMTP(host, port, timeout=15) as server:
        server.ehlo()
        if os.getenv("SMTP_TLS", "true").lower() == "true": server.starttls(); server.ehlo()
        user = os.getenv("SMTP_USER", "")
        if user: server.login(user, os.getenv("SMTP_PASSWORD", ""))
        server.send_message(msg)
    return True

def consume_auth_token(raw: str, purpose: str):
    if not raw or len(raw) > 200:
        raise HTTPException(400, "پیوند نامعتبر یا منقضی شده است.")
    digest = hashlib.sha256(raw.encode()).hexdigest()
    now = datetime.now(timezone.utc).isoformat()
    with db() as c:
        row = c.execute("SELECT * FROM auth_tokens WHERE token_hash=? AND purpose=? AND used_at IS NULL AND expires_at>?",
                        (digest, purpose, now)).fetchone()
        if not row: raise HTTPException(400, "پیوند نامعتبر یا منقضی شده است.")
        c.execute("UPDATE auth_tokens SET used_at=? WHERE token_hash=? AND used_at IS NULL", (now, digest))
    return row["user_id"]

def current_user(request: Request):
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        raise HTTPException(status_code=401, detail="ابتدا وارد حساب شوید.")
    with db() as c:
        row = c.execute("""SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id
            WHERE s.token_hash=? AND s.expires_at>?""",
            (token_digest(token), datetime.now(timezone.utc).isoformat())).fetchone()
    if not row:
        raise HTTPException(status_code=401, detail="نشست شما منقضی شده است. دوباره وارد شوید.")
    if row["status"] != "active":
        raise HTTPException(status_code=403, detail="این حساب موقتاً غیرفعال شده است.")
    return row

def require_admin(user=Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="دسترسی مدیر سامانه لازم است.")
    return user

def create_session(response: Response, user_id: int):
    token = secrets.token_urlsafe(40)
    expires = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    with db() as c:
        c.execute("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)",
                  (token_digest(token), user_id, expires.isoformat()))
    response.set_cookie(
        SESSION_COOKIE, token, httponly=True, secure=COOKIE_SECURE,
        samesite="lax", max_age=SESSION_DAYS * 86400, path="/"
    )

@app.get("/verify-email", response_class=HTMLResponse)
def verify_email_page(token: str = ""):
    safe_token = token.replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;")
    return HTMLResponse(f"""<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>تأیید ایمیل | FOOTBALL LIVE</title><body style='font-family:Tahoma,Arial;background:#081925;color:#eaf4f5;display:grid;place-items:center;min-height:90vh'><main style='background:#102b39;padding:28px;border-radius:18px;max-width:420px;width:88%'><h2>تأیید ایمیل</h2><p>برای فعال‌سازی حساب، دکمه زیر را بزن.</p><button id='go' style='padding:12px 20px;border:0;border-radius:9px;background:#16805e;color:white'>تأیید ایمیل</button><p id='msg'></p><a href='/' style='color:#8bd9bd'>بازگشت به سایت</a></main><script>document.getElementById('go').onclick=async()=>{{let r=await fetch('/api/auth/verify-email',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{token:'{safe_token}'}})}});let d=await r.json();document.getElementById('msg').textContent=d.message||d.detail||'خطا';}}</script></body></html>""")

@app.get("/reset-password", response_class=HTMLResponse)
def reset_password_page(token: str = ""):
    safe_token = token.replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;")
    return HTMLResponse(f"""<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>بازیابی رمز | FOOTBALL LIVE</title><body style='font-family:Tahoma,Arial;background:#081925;color:#eaf4f5;display:grid;place-items:center;min-height:90vh'><main style='background:#102b39;padding:28px;border-radius:18px;max-width:420px;width:88%'><h2>تعیین رمز عبور جدید</h2><form id='f'><input name='pw' type='password' minlength='10' maxlength='128' required placeholder='رمز جدید؛ حداقل ۱۰ نویسه' style='box-sizing:border-box;width:100%;padding:12px;margin:12px 0'><button style='padding:12px 20px;border:0;border-radius:9px;background:#16805e;color:white'>ذخیره رمز جدید</button></form><p id='msg'></p><a href='/' style='color:#8bd9bd'>بازگشت به سایت</a></main><script>document.getElementById('f').onsubmit=async e=>{{e.preventDefault();let r=await fetch('/api/auth/reset-password',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{token:'{safe_token}',new_password:e.target.pw.value}})}});let d=await r.json();document.getElementById('msg').textContent=d.message||d.detail||'خطا';}}</script></body></html>""")

@app.get("/admin")
def admin_page():
    return FileResponse(BASE / "static" / "admin.html")

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.post("/api/auth/register", status_code=201)
def register(data: Signup):
    now = datetime.now(timezone.utc).isoformat()
    # email remains as an internal legacy-compatible database field; users sign in with phone only.
    legacy_email = data.phone.replace("+", "") + "@phone.invalid"
    try:
        with db() as c:
            cur = c.execute("INSERT INTO users(email,phone,display_name,password_hash,created_at,email_verified) VALUES(?,?,?,?,?,1)",
                (legacy_email, data.phone, data.display_name, hash_password(data.password), now))
            user_id = cur.lastrowid
    except sqlite3.IntegrityError:
        raise HTTPException(409, "این شماره موبایل قبلاً ثبت شده است.")
    return {"message": "حساب با شماره موبایل ساخته شد. اکنون می‌توانید وارد شوید.", "user_id": user_id}

@app.post("/api/auth/login")
def login(data: Login, response: Response):
    with db() as c:
        row = c.execute("SELECT * FROM users WHERE phone=?", (data.phone,)).fetchone()
    if not row or not verify_password(data.password, row["password_hash"]):
        raise HTTPException(401, "شماره موبایل یا رمز عبور صحیح نیست.")
    if row["status"] != "active": raise HTTPException(403, "این حساب موقتاً غیرفعال شده است.")
    create_session(response, row["id"])
    return {"user": public_user(row), "message": "ورود موفق بود."}

class EmailAction(BaseModel):
    email: str = Field(min_length=5, max_length=254)

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value):
        return value.strip().lower()

class TokenAction(BaseModel):
    token: str = Field(min_length=20, max_length=200)

class PasswordReset(TokenAction):
    new_password: str = Field(min_length=10, max_length=128)

@app.post("/api/auth/resend-verification")
def resend_verification(data: EmailAction):
    with db() as c:
        row = c.execute("SELECT id,email,email_verified FROM users WHERE email=?", (data.email,)).fetchone()
    # Same response for unknown and already-verified addresses to reduce account enumeration.
    result = {"message": "اگر حساب نیازمند تأیید باشد، ایمیل راهنما ارسال می‌شود."}
    if row and not row["email_verified"]:
        token = issue_auth_token(row["id"], "verify_email", 24)
        sent = send_auth_email(row["email"], "verify_email", token)
        result["email_sent"] = sent
        if APP_ENV != "production" and EMAIL_DEV_MODE: result["development_token"] = token
    return result

@app.post("/api/auth/verify-email")
def verify_email(data: TokenAction):
    user_id = consume_auth_token(data.token, "verify_email")
    with db() as c:
        c.execute("UPDATE users SET email_verified=1 WHERE id=?", (user_id,))
    return {"message": "ایمیل با موفقیت تأیید شد. اکنون می‌توانید وارد شوید."}

@app.post("/api/auth/forgot-password")
def forgot_password(data: EmailAction):
    with db() as c:
        row = c.execute("SELECT id,email,email_verified FROM users WHERE email=?", (data.email,)).fetchone()
    result = {"message": "اگر حسابی با این ایمیل وجود داشته باشد، راهنمای بازیابی ارسال می‌شود."}
    if row and row["email_verified"]:
        token = issue_auth_token(row["id"], "reset_password", 1)
        sent = send_auth_email(row["email"], "reset_password", token)
        result["email_sent"] = sent
        if APP_ENV != "production" and EMAIL_DEV_MODE: result["development_token"] = token
    return result

@app.post("/api/auth/reset-password")
def reset_password(data: PasswordReset):
    user_id = consume_auth_token(data.token, "reset_password")
    with db() as c:
        c.execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(data.new_password), user_id))
        c.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
    return {"message": "رمز عبور تغییر کرد. برای ورود دوباره اقدام کنید."}

@app.post("/api/auth/logout")
def logout(request: Request, response: Response):
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        with db() as c:
            c.execute("DELETE FROM sessions WHERE token_hash=?", (token_digest(token),))
    response.delete_cookie(SESSION_COOKIE, path="/", httponly=True, secure=COOKIE_SECURE, samesite="lax")
    return {"message": "از حساب خارج شدید."}

@app.get("/api/me")
def me(user=Depends(current_user)):
    return {"user": public_user(user)}

@app.put("/api/profile")
def update_profile(data: ProfileUpdate, user=Depends(current_user)):
    teams = list(dict.fromkeys(x.strip()[:60] for x in data.favorite_teams if x.strip()))[:20]
    with db() as c:
        c.execute("""UPDATE users SET display_name=?, avatar_url=?, favorite_teams=? WHERE id=?""",
                  (data.display_name.strip(), data.avatar_url.strip(), "|".join(teams), user["id"]))
        row = c.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
    return {"user": public_user(row), "message": "پروفایل به‌روزرسانی شد."}

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "FOOTBALL LIVE"}


class AdminBootstrap(BaseModel):
    phone: str
    bootstrap_key: str = Field(min_length=16, max_length=256)

class UserReport(BaseModel):
    target_user_id: int = Field(gt=0)
    reason: str = Field(min_length=10, max_length=500)

@app.post("/api/admin/bootstrap")
def admin_bootstrap(data: AdminBootstrap):
    # One-time promotion, only when an operator has configured a private key on the server.
    if not ADMIN_BOOTSTRAP_KEY or not hmac.compare_digest(data.bootstrap_key, ADMIN_BOOTSTRAP_KEY):
        raise HTTPException(403, "کلید راه‌اندازی مدیر معتبر نیست یا روی سرور تنظیم نشده است.")
    phone = data.phone.strip()
    with db() as c:
        if c.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone():
            raise HTTPException(409, "مدیر سامانه قبلاً تعیین شده است.")
        cur = c.execute("UPDATE users SET role='admin' WHERE phone=?", (phone,))
        if cur.rowcount != 1:
            raise HTTPException(404, "ابتدا با همین شماره موبایل یک حساب کاربری بسازید.")
    return {"message": "نقش مدیر فعال شد. دوباره وارد حساب شوید."}

@app.get("/api/admin/summary")
def admin_summary(admin=Depends(require_admin)):
    with db() as c:
        users = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        active = c.execute("SELECT COUNT(*) FROM users WHERE status='active'").fetchone()[0]
        suspended = c.execute("SELECT COUNT(*) FROM users WHERE status='suspended'").fetchone()[0]
        open_reports = c.execute("SELECT COUNT(*) FROM reports WHERE status='open'").fetchone()[0]
    return {"users": users, "active_users": active, "suspended_users": suspended, "open_reports": open_reports}

@app.get("/api/admin/users")
def admin_users(admin=Depends(require_admin)):
    with db() as c:
        rows = c.execute("SELECT id,phone,display_name,role,status,created_at FROM users ORDER BY id DESC LIMIT 200").fetchall()
    return {"users": [dict(r) for r in rows]}

@app.patch("/api/admin/users/{user_id}/status")
def admin_set_user_status(user_id: int, status: str, admin=Depends(require_admin)):
    if status not in ("active", "suspended"):
        raise HTTPException(400, "وضعیت نامعتبر است.")
    if user_id == admin["id"]:
        raise HTTPException(400, "مدیر نمی‌تواند حساب خودش را غیرفعال کند.")
    with db() as c:
        cur = c.execute("UPDATE users SET status=? WHERE id=? AND role!='admin'", (status, user_id))
        if cur.rowcount != 1:
            raise HTTPException(404, "کاربر پیدا نشد یا امکان تغییر وضعیت او وجود ندارد.")
        if status == "suspended":
            c.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
    return {"message": "وضعیت حساب به‌روزرسانی شد.", "status": status}

@app.post("/api/reports", status_code=201)
def create_report(data: UserReport, user=Depends(current_user)):
    if data.target_user_id == user["id"]:
        raise HTTPException(400, "نمی‌توانید حساب خودتان را گزارش کنید.")
    with db() as c:
        target = c.execute("SELECT id FROM users WHERE id=?", (data.target_user_id,)).fetchone()
        if not target:
            raise HTTPException(404, "کاربر موردنظر پیدا نشد.")
        cur = c.execute("INSERT INTO reports(reporter_id,target_user_id,reason,created_at) VALUES(?,?,?,?)",
            (user["id"], data.target_user_id, data.reason.strip(), datetime.now(timezone.utc).isoformat()))
    return {"report_id": cur.lastrowid, "message": "گزارش برای بررسی ثبت شد."}

@app.get("/api/admin/reports")
def admin_reports(admin=Depends(require_admin)):
    with db() as c:
        rows = c.execute("""SELECT r.id,r.reason,r.status,r.created_at,
            a.phone AS reporter_phone,b.phone AS target_phone,b.display_name AS target_name
            FROM reports r JOIN users a ON a.id=r.reporter_id JOIN users b ON b.id=r.target_user_id
            ORDER BY CASE r.status WHEN 'open' THEN 0 ELSE 1 END,r.id DESC LIMIT 200""").fetchall()
    return {"reports": [dict(r) for r in rows]}

@app.patch("/api/admin/reports/{report_id}/resolve")
def resolve_report(report_id: int, admin=Depends(require_admin)):
    with db() as c:
        cur = c.execute("UPDATE reports SET status='reviewed' WHERE id=? AND status='open'", (report_id,))
        if cur.rowcount != 1:
            raise HTTPException(404, "گزارش باز پیدا نشد.")
    return {"message": "گزارش به‌عنوان بررسی‌شده ثبت شد."}


# Football data provider: API-Football / API-Sports. The key stays server-side.
def _football_get(endpoint: str, params: dict):
    if not FOOTBALL_API_KEY:
        raise HTTPException(503, "داده زنده هنوز فعال نشده است؛ مدیر سایت باید کلید معتبر سرویس فوتبال را روی سرور تنظیم کند.")
    try:
        response = httpx.get(
            f"{FOOTBALL_API_BASE}/{endpoint.lstrip('/')}", params=params,
            headers={"x-apisports-key": FOOTBALL_API_KEY},
            timeout=httpx.Timeout(14.0, connect=5.0),
        )
    except httpx.TimeoutException:
        raise HTTPException(504, "سرویس فوتبال دیر پاسخ داد. کمی بعد دوباره تلاش کن.")
    except httpx.RequestError:
        raise HTTPException(502, "ارتباط با سرویس فوتبال برقرار نشد.")
    if response.status_code in (401, 403):
        raise HTTPException(502, "کلید سرویس فوتبال معتبر نیست یا طرح انتخابی دسترسی لازم را ندارد.")
    if response.status_code == 429:
        raise HTTPException(503, "سهمیه درخواست سرویس فوتبال تمام شده است. بعداً دوباره تلاش کن.")
    if response.status_code >= 500:
        raise HTTPException(502, "سرویس فوتبال موقتاً در دسترس نیست.")
    if response.status_code != 200:
        raise HTTPException(502, "پاسخ نامعتبر از سرویس فوتبال دریافت شد.")
    try:
        data = response.json()
    except ValueError:
        raise HTTPException(502, "پاسخ سرویس فوتبال قابل خواندن نیست.")
    if data.get("errors"):
        raise HTTPException(502, "سرویس فوتبال درخواست را نپذیرفت؛ پوشش یا تنظیمات API باید بررسی شود.")
    return data.get("response", [])

def _football_request(params: dict):
    return _football_get("fixtures", params)

FEATURED_LEAGUES = [
    {"id": 39, "name": "Premier League", "fa": "لیگ برتر انگلیس", "country": "انگلیس", "logo": "https://media.api-sports.io/football/leagues/39.png"},
    {"id": 140, "name": "La Liga", "fa": "لالیگا", "country": "اسپانیا", "logo": "https://media.api-sports.io/football/leagues/140.png"},
    {"id": 135, "name": "Serie A", "fa": "سری آ ایتالیا", "country": "ایتالیا", "logo": "https://media.api-sports.io/football/leagues/135.png"},
    {"id": 78, "name": "Bundesliga", "fa": "بوندس‌لیگا", "country": "آلمان", "logo": "https://media.api-sports.io/football/leagues/78.png"},
    {"id": 61, "name": "Ligue 1", "fa": "لیگ ۱ فرانسه", "country": "فرانسه", "logo": "https://media.api-sports.io/football/leagues/61.png"},
    {"id": 2, "name": "UEFA Champions League", "fa": "لیگ قهرمانان اروپا", "country": "اروپا", "logo": "https://media.api-sports.io/football/leagues/2.png"},
    {"id": 3, "name": "UEFA Europa League", "fa": "لیگ اروپا", "country": "اروپا", "logo": "https://media.api-sports.io/football/leagues/3.png"},
    {"id": 848, "name": "UEFA Conference League", "fa": "لیگ کنفرانس اروپا", "country": "اروپا", "logo": "https://media.api-sports.io/football/leagues/848.png"},
    {"id": 45, "name": "FA Cup", "fa": "جام حذفی انگلیس", "country": "انگلیس", "logo": "https://media.api-sports.io/football/leagues/45.png"},
    {"id": 143, "name": "Copa del Rey", "fa": "جام حذفی اسپانیا", "country": "اسپانیا", "logo": "https://media.api-sports.io/football/leagues/143.png"},
    {"id": 88, "name": "Eredivisie", "fa": "اردیویسه", "country": "هلند", "logo": "https://media.api-sports.io/football/leagues/88.png"},
    {"id": 94, "name": "Primeira Liga", "fa": "لیگ پرتغال", "country": "پرتغال", "logo": "https://media.api-sports.io/football/leagues/94.png"},
    {"id": 253, "name": "MLS", "fa": "لیگ آمریکا", "country": "آمریکا", "logo": "https://media.api-sports.io/football/leagues/253.png"},
    {"id": 307, "name": "Saudi Pro League", "fa": "لیگ حرفه‌ای عربستان", "country": "عربستان", "logo": "https://media.api-sports.io/football/leagues/307.png"},
    {"id": 203, "name": "Süper Lig", "fa": "سوپر لیگ ترکیه", "country": "ترکیه", "logo": "https://media.api-sports.io/football/leagues/203.png"},
    {"id": 71, "name": "Serie A Brazil", "fa": "سری آ برزیل", "country": "برزیل", "logo": "https://media.api-sports.io/football/leagues/71.png"},
    {"id": 128, "name": "Liga Profesional Argentina", "fa": "لیگ حرفه‌ای آرژانتین", "country": "آرژانتین", "logo": "https://media.api-sports.io/football/leagues/128.png"},
    {"id": 262, "name": "Liga MX", "fa": "لیگ مکزیک", "country": "مکزیک", "logo": "https://media.api-sports.io/football/leagues/262.png"},
    {"id": 292, "name": "K League 1", "fa": "کی‌لیگ کره جنوبی", "country": "کره جنوبی", "logo": "https://media.api-sports.io/football/leagues/292.png"},
    {"id": 169, "name": "Persian Gulf Pro League", "fa": "لیگ برتر ایران", "country": "ایران", "logo": "https://media.api-sports.io/football/leagues/169.png"},
    {"id": 40, "name": "Championship", "fa": "چمپیونشیپ انگلیس", "country": "انگلیس", "logo": "https://media.api-sports.io/football/leagues/40.png"},
    {"id": 81, "name": "DFB Pokal", "fa": "جام حذفی آلمان", "country": "آلمان", "logo": "https://media.api-sports.io/football/leagues/81.png"},
    {"id": 137, "name": "Coppa Italia", "fa": "جام حذفی ایتالیا", "country": "ایتالیا", "logo": "https://media.api-sports.io/football/leagues/137.png"},
    {"id": 98, "name": "J1 League", "fa": "جی‌لیگ ژاپن", "country": "ژاپن", "logo": "https://media.api-sports.io/football/leagues/98.png"},
    {"id": 1, "name": "FIFA World Cup", "fa": "جام جهانی", "country": "جهانی", "logo": "https://media.api-sports.io/football/leagues/1.png"}
]

def _current_season():
    configured = os.getenv("FOOTBALL_SEASON", "").strip()
    if configured.isdigit() and len(configured) == 4:
        return int(configured)
    now = datetime.now(timezone.utc)
    return now.year if now.month >= 7 else now.year - 1

@app.get("/api/football/leagues")
def football_leagues():
    return {"season": _current_season(), "leagues": FEATURED_LEAGUES,
            "source": "API-Football competition catalogue; selected major competitions"}

@app.get("/api/football/standings")
def football_standings(league: int):
    allowed = {x["id"] for x in FEATURED_LEAGUES}
    if league not in allowed:
        raise HTTPException(400, "این رقابت در فهرست لیگ‌های منتخب سایت نیست.")
    season = _current_season()
    data = _football_get("standings", {"league": league, "season": season})
    if not data:
        return {"league_id": league, "season": season, "groups": [], "source": "API-Football"}
    league_data = (data[0].get("league") or {})
    groups = []
    for group in (league_data.get("standings") or []):
        groups.append([{
            "rank": row.get("rank"), "team": (row.get("team") or {}).get("name", "—"),
            "logo": (row.get("team") or {}).get("logo"), "played": (row.get("all") or {}).get("played"),
            "win": (row.get("all") or {}).get("win"), "draw": (row.get("all") or {}).get("draw"),
            "lose": (row.get("all") or {}).get("lose"), "goals_for": (row.get("all") or {}).get("goals", {}).get("for"),
            "goals_against": (row.get("all") or {}).get("goals", {}).get("against"),
            "goal_diff": row.get("goalsDiff"), "points": row.get("points"), "form": row.get("form"),
        } for row in group])
    return {"league_id": league, "league": league_data.get("name"), "season": season,
            "groups": groups, "source": "API-Football"}

# Publisher RSS feeds: show links/snippets, not copied full articles.
NEWS_FEEDS = [
    ("BBC Sport", "https://feeds.bbci.co.uk/sport/football/rss.xml"),
    ("The Guardian", "https://www.theguardian.com/football/rss"),
]
TRANSFER_WORDS = ("transfer", "transfers", "sign", "signing", "loan", "deal", "contract", "bid", "رسمی", "انتقال", "قرارداد", "خرید", "فروش")
def _read_football_rss(transfers_only=False):
    import xml.etree.ElementTree as ET
    articles = []
    for source, feed_url in NEWS_FEEDS:
        try:
            r = httpx.get(feed_url, timeout=httpx.Timeout(9.0, connect=4.0),
                          headers={"User-Agent": "FOOTBALL-LIVE/1.6 (sports headlines; contact: site-admin)"})
            r.raise_for_status()
            root = ET.fromstring(r.content)
            for item in root.findall(".//item")[:35]:
                title = (item.findtext("title") or "").strip()
                link = (item.findtext("link") or "").strip()
                description = (item.findtext("description") or "").strip()
                pub = (item.findtext("pubDate") or "").strip()
                if not title or not link.startswith("https://"):
                    continue
                haystack = (title + " " + description).lower()
                is_transfer = any(word in haystack for word in TRANSFER_WORDS)
                if transfers_only and not is_transfer:
                    continue
                # Strip RSS markup from the short description.
                summary = re.sub(r"<[^>]+>", " ", description)
                summary = re.sub(r"\s+", " ", summary).strip()
                articles.append({"title": title, "summary": summary[:360], "url": link,
                                 "published": pub, "source": source,
                                 "kind": "گزارش رسانه‌ای؛ تا اعلام رسمی باشگاه قطعی محسوب نمی‌شود" if transfers_only else "خبر رسانه‌ای"})
        except Exception:
            continue
    articles.sort(key=lambda x: x.get("published", ""), reverse=True)
    return articles[:30]

@app.get("/api/football/news")
def football_news():
    items = _read_football_rss(False)
    if not items:
        raise HTTPException(503, "در حال حاضر دریافت خبر از منابع رسانه‌ای ممکن نیست. بعداً دوباره تلاش کن.")
    return {"count": len(items), "items": items, "sources": [x[0] for x in NEWS_FEEDS]}

@app.get("/api/football/transfers")
def football_transfers():
    items = _read_football_rss(True)
    if not items:
        raise HTTPException(503, "در حال حاضر خبر مرتبط با نقل‌وانتقالات از منابع رسانه‌ای دریافت نشد.")
    return {"count": len(items), "items": items, "sources": [x[0] for x in NEWS_FEEDS],
            "notice": "این بخش خبرها و گزارش‌های رسانه‌ای را گردآوری می‌کند؛ شایعه یا گزارش تا تأیید رسمی باشگاه، انتقال قطعی نیست."}

def _normalize_fixture(item: dict):
    fixture = item.get("fixture") or {}
    league = item.get("league") or {}
    teams = item.get("teams") or {}
    goals = item.get("goals") or {}
    home = teams.get("home") or {}
    away = teams.get("away") or {}
    status = fixture.get("status") or {}
    return {
        "id": fixture.get("id"),
        "date": fixture.get("date"),
        "timestamp": fixture.get("timestamp"),
        "status": status.get("long") or status.get("short") or "نامشخص",
        "short_status": status.get("short") or "—",
        "elapsed": status.get("elapsed"),
        "league": league.get("name") or "مسابقه",
        "country": league.get("country") or "",
        "round": league.get("round") or "",
        "home": home.get("name") or "تیم میزبان",
        "away": away.get("name") or "تیم مهمان",
        "home_logo": home.get("logo"),
        "away_logo": away.get("logo"),
        "home_goals": goals.get("home"),
        "away_goals": goals.get("away"),
    }

@app.get("/api/football/live")
def football_live():
    items = _football_request({"live": "all", "timezone": FOOTBALL_TIMEZONE})
    matches = [_normalize_fixture(x) for x in items]
    return {"source": "API-Football", "live": True, "count": len(matches), "matches": matches}

@app.get("/api/football/today")
def football_today():
    try:
        today = datetime.now(ZoneInfo(FOOTBALL_TIMEZONE)).date().isoformat()
    except Exception:
        today = datetime.now(timezone.utc).date().isoformat()
    items = _football_request({"date": today, "timezone": FOOTBALL_TIMEZONE})
    matches = [_normalize_fixture(x) for x in items]
    return {"source": "API-Football", "date": today, "count": len(matches), "matches": matches}

@app.get("/api/football/config")
def football_config():
    return {"configured": bool(FOOTBALL_API_KEY), "timezone": FOOTBALL_TIMEZONE}
