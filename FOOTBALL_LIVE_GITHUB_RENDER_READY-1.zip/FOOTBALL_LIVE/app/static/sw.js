const CACHE="football-live-v1-8";
const SHELL=["/","/static/index.html"];
self.addEventListener("install",event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL))));
self.addEventListener("activate",event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key))))));
self.addEventListener("fetch",event=>{
  if(event.request.method!=="GET")return;
  const url=new URL(event.request.url);
  // Live scores, standings, news and transfer reports must never be served from stale cache.
  if(url.origin===self.location.origin && url.pathname.startsWith("/api/")){
    event.respondWith(fetch(event.request));
    return;
  }
  if(url.origin!==self.location.origin)return;
  event.respondWith(fetch(event.request).then(response=>{
    if(response.ok && (url.pathname==="/" || url.pathname.startsWith("/static/"))){
      const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy));
    }
    return response;
  }).catch(()=>caches.match(event.request).then(response=>response||caches.match("/"))));
});
